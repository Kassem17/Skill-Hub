import React from 'react'

const ProgressTracker = () => {
  return (
    <div>ProgressTracker</div>
  )
}

export default ProgressTracker